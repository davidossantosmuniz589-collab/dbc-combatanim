package dbcanim;

import net.minecraft.entity.player.EntityPlayer;

/**
 * PONTO A AJUSTAR: como saber se o jogador esta defendendo (bloqueio) no Dragon Block C.
 * Por padrao usa o bloqueio vanilla (isBlocking). Troque pelo flag/NBT que o DBC/JRMCore usa para o bloqueio.
 */
public final class DefenseCheck {
    public static boolean isDefending(EntityPlayer p) {
        return p.isBlocking();
    }
}
