package dbcanim;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = DbcAnimMod.MODID, name = "DBC Combat Anim", version = "1.0", acceptableRemoteVersions = "*")
public class DbcAnimMod {
    public static final String MODID = "dbcanim";

    @Mod.EventHandler
    @SideOnly(Side.CLIENT)
    public void init(FMLInitializationEvent e) {
        MinecraftForge.EVENT_BUS.register(new RenderEvents());
    }
}
