package dbcanim;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import dbcanim.anim.AnimHook;
import dbcanim.anim.Clip;
import dbcanim.anim.ComboData;
import dbcanim.anim.Pose;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** Escolhe a animacao (soco aleatorio 1-6 ao bater, defesa ao defender) e aplica o "root" via OpenGL. */
public class RenderEvents {
    private static final class State { int idx; float last; float defW; }

    private final Map<Integer, State> states = new HashMap<Integer, State>();
    private final Random rnd = new Random();
    private boolean pushed;

    @SubscribeEvent
    public void pre(RenderPlayerEvent.Pre e) {
        EntityPlayer p = e.entityPlayer;
        State s = states.get(p.getEntityId());
        if (s == null) { s = new State(); states.put(p.getEntityId(), s); }

        float swing = p.getSwingProgress(e.partialRenderTick);
        boolean def = DefenseCheck.isDefending(p);
        s.defW += ((def ? 1f : 0f) - s.defW) * 0.3f;
        if (swing > 0f && (s.last == 0f || swing < s.last)) s.idx = rnd.nextInt(ComboData.ATTACKS.length);
        s.last = swing;

        Pose pose = null;
        if (s.defW > 0.02f) {
            pose = Pose.sample(ComboData.DEFENSE, 0f, s.defW);
        } else if (swing > 0f) {
            Clip c = ComboData.ATTACKS[s.idx];
            float fade = Math.min(1f, Math.min(swing / 0.12f, (1f - swing) / 0.18f));
            fade = Math.max(0f, fade);
            pose = Pose.sample(c, swing * c.length, fade * fade * (3f - 2f * fade)); // smoothstep
        }
        if (pose == null) { AnimHook.CURRENT = null; AnimHook.ENTITY = null; pushed = false; return; }

        AnimHook.CURRENT = pose;
        AnimHook.ENTITY = p;

        // osso "root": desloca/gira o corpo todo (so Y e rotacao em Y)
        GL11.glPushMatrix();
        pushed = true;
        float[] rp = pose.hasPos[Clip.ROOT] ? pose.pos[Clip.ROOT] : new float[3];
        float[] rr = pose.hasRot[Clip.ROOT] ? pose.rot[Clip.ROOT] : new float[3];
        GL11.glTranslatef(0f, rp[1] / 16f * pose.weight, 0f);
        GL11.glRotatef(AnimHook.SY * rr[1] * pose.weight, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public void post(RenderPlayerEvent.Post e) {
        if (pushed) { GL11.glPopMatrix(); pushed = false; }
        AnimHook.CURRENT = null;
        AnimHook.ENTITY = null;
    }
}
