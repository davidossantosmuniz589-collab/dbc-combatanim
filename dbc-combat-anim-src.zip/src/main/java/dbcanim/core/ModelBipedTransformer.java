package dbcanim.core;

import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

/** Injeta "AnimHook.apply(this, entity)" no fim de ModelBiped.setRotationAngles(FFFFFFLEntity;)V. */
public class ModelBipedTransformer implements IClassTransformer {
    private static final String DESC = "(FFFFFFLnet/minecraft/entity/Entity;)V";

    public byte[] transform(String name, String transformedName, byte[] bytes) {
        if (bytes == null || !"net.minecraft.client.model.ModelBiped".equals(transformedName)) return bytes;
        ClassNode cn = new ClassNode();
        new ClassReader(bytes).accept(cn, 0);
        for (MethodNode mn : cn.methods) {
            boolean nameOk = "setRotationAngles".equals(mn.name) || "func_78087_a".equals(mn.name);
            if (!nameOk || !DESC.equals(mn.desc)) continue;
            for (AbstractInsnNode in : mn.instructions.toArray()) {
                if (in.getOpcode() == Opcodes.RETURN) {
                    InsnList il = new InsnList();
                    il.add(new VarInsnNode(Opcodes.ALOAD, 0));
                    il.add(new VarInsnNode(Opcodes.ALOAD, 7));
                    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "dbcanim/anim/AnimHook", "apply",
                            "(Lnet/minecraft/client/model/ModelBiped;Lnet/minecraft/entity/Entity;)V", false));
                    mn.instructions.insertBefore(in, il);
                }
            }
        }
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }
}
