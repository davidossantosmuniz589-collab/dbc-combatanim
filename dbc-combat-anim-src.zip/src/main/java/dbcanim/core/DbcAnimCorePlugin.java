package dbcanim.core;

import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
import java.util.Map;

@IFMLLoadingPlugin.TransformerExclusions({"dbcanim.core."})
@IFMLLoadingPlugin.MCVersion("1.7.10")
public class DbcAnimCorePlugin implements IFMLLoadingPlugin {
    public String[] getASMTransformerClass() { return new String[]{"dbcanim.core.ModelBipedTransformer"}; }
    public String getModContainerClass() { return null; }
    public String getSetupClass() { return null; }
    public void injectData(Map<String, Object> data) {}
    public String getAccessTransformerClass() { return null; }
}
