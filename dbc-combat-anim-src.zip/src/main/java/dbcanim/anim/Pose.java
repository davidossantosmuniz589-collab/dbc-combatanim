package dbcanim.anim;

/** Pose avaliada de um Clip num instante: rotacao (graus) e posicao (px) por osso, mais o peso de mistura 0..1. */
public final class Pose {
    public final float[][] rot = new float[Clip.N][3];
    public final float[][] pos = new float[Clip.N][3];
    public final boolean[] hasRot = new boolean[Clip.N];
    public final boolean[] hasPos = new boolean[Clip.N];
    public float weight;

    public static Pose sample(Clip c, float time, float weight) {
        Pose p = new Pose();
        p.weight = weight;
        for (int b = 0; b < Clip.N; b++) {
            if (c.rt[b] != null) { Clip.sample(c.rt[b], c.rv[b], time, p.rot[b]); p.hasRot[b] = true; }
            if (c.pt[b] != null) { Clip.sample(c.pt[b], c.pv[b], time, p.pos[b]); p.hasPos[b] = true; }
        }
        return p;
    }
}
