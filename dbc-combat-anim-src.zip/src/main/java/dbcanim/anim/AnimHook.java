package dbcanim.anim;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.Entity;

/**
 * Chamado pelo fim de ModelBiped.setRotationAngles (injetado por ModelBipedTransformer).
 * So age enquanto RenderEvents estiver entre Pre e Post do jogador (evita afetar a mao em 1a pessoa).
 *
 * CONVENCAO Bedrock -> Java (ajuste aqui se algum eixo ficar invertido no teste):
 *   rotacao X/Z como esta, Y invertido; posicao Y invertida (Bedrock: +Y sobe; Java: +Y desce).
 */
public final class AnimHook {
    public static volatile Pose CURRENT;
    public static volatile Entity ENTITY;

    public static final float SX = 1f, SY = -1f, SZ = 1f;   // sinais de rotacao
    public static final float PX = 1f, PY = -1f, PZ = 1f;   // sinais de posicao

    private static float rad(float deg) { return (float) Math.toRadians(deg); }

    public static void apply(ModelBiped m, Entity e) {
        Pose p = CURRENT;
        if (p == null || e != ENTITY) return;
        float w = p.weight;

        float[] waist = p.hasRot[Clip.WAIST] ? p.rot[Clip.WAIST] : ZERO;
        float[] body  = p.hasRot[Clip.BODY]  ? p.rot[Clip.BODY]  : ZERO;
        float[] wpos  = p.hasPos[Clip.WAIST] ? p.pos[Clip.WAIST] : ZERO;

        // Tronco: "waist" + "body" (absoluto, misturado com a pose vanilla)
        m.bipedBody.rotateAngleX = lerp(m.bipedBody.rotateAngleX, rad(SX * (waist[0] + body[0])), w);
        m.bipedBody.rotateAngleY = lerp(m.bipedBody.rotateAngleY, rad(SY * (waist[1] + body[1])), w);
        m.bipedBody.rotateAngleZ = lerp(m.bipedBody.rotateAngleZ, rad(SZ * (waist[2] + body[2])), w);
        m.bipedBody.rotationPointY += PY * wpos[1] * w;

        // Cabeca: soma (mantem o olhar vanilla) + inclinacao do tronco (aproximacao: Bedrock tem hierarquia, Java nao)
        float[] head = p.hasRot[Clip.HEAD] ? p.rot[Clip.HEAD] : ZERO;
        addRot(m.bipedHead, w, head[0] + waist[0], head[1] + waist[1], head[2] + waist[2]);
        m.bipedHead.rotationPointY += PY * wpos[1] * w;
        copy(m.bipedHead, m.bipedHeadwear);

        arm(m.bipedRightArm, p, Clip.RARM, waist, wpos, w);
        arm(m.bipedLeftArm,  p, Clip.LARM, waist, wpos, w);
        leg(m.bipedRightLeg, p, Clip.RLEG, w);
        leg(m.bipedLeftLeg,  p, Clip.LLEG, w);
    }

    private static final float[] ZERO = new float[3];

    private static void arm(net.minecraft.client.model.ModelRenderer r, Pose p, int b, float[] waist, float[] wpos, float w) {
        if (p.hasRot[b]) {
            float[] a = p.rot[b];
            // absoluto + giro/inclinacao do tronco somados (aproximacao da hierarquia waist -> arm)
            r.rotateAngleX = lerp(r.rotateAngleX, rad(SX * (a[0] + waist[0])), w);
            r.rotateAngleY = lerp(r.rotateAngleY, rad(SY * (a[1] + waist[1])), w);
            r.rotateAngleZ = lerp(r.rotateAngleZ, rad(SZ * a[2]), w);
        }
        float[] q = p.hasPos[b] ? p.pos[b] : ZERO;
        r.rotationPointX += PX * q[0] * w;
        r.rotationPointY += PY * (q[1] + wpos[1]) * w;
        r.rotationPointZ += PZ * q[2] * w;
    }

    private static void leg(net.minecraft.client.model.ModelRenderer r, Pose p, int b, float w) {
        if (p.hasRot[b]) {
            float[] a = p.rot[b];
            r.rotateAngleX = lerp(r.rotateAngleX, rad(SX * a[0]), w);
            r.rotateAngleY = lerp(r.rotateAngleY, rad(SY * a[1]), w);
            r.rotateAngleZ = lerp(r.rotateAngleZ, rad(SZ * a[2]), w);
        }
        float[] q = p.hasPos[b] ? p.pos[b] : ZERO;
        r.rotationPointX += PX * q[0] * w;
        r.rotationPointY += PY * q[1] * w;
        r.rotationPointZ += PZ * q[2] * w;
    }

    private static void addRot(net.minecraft.client.model.ModelRenderer r, float w, float x, float y, float z) {
        r.rotateAngleX += rad(SX * x) * w;
        r.rotateAngleY += rad(SY * y) * w;
        r.rotateAngleZ += rad(SZ * z) * w;
    }

    private static void copy(net.minecraft.client.model.ModelRenderer from, net.minecraft.client.model.ModelRenderer to) {
        if (to == null) return;
        to.rotateAngleX = from.rotateAngleX; to.rotateAngleY = from.rotateAngleY; to.rotateAngleZ = from.rotateAngleZ;
        to.rotationPointX = from.rotationPointX; to.rotationPointY = from.rotationPointY; to.rotationPointZ = from.rotationPointZ;
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
}
