package dbcanim.anim;

/** Animacao: por osso, keyframes de rotacao (graus) e posicao (pixels), no formato Bedrock. */
public final class Clip {
    public static final int WAIST = 0, ROOT = 1, HEAD = 2, RARM = 3, LARM = 4, RLEG = 5, LLEG = 6, BODY = 7, N = 8;

    public final float length;
    public final float[][] rt = new float[N][], pt = new float[N][];
    public final float[][][] rv = new float[N][][], pv = new float[N][][];

    public Clip(float length) { this.length = length; }

    public void set(int bone, float[] rotT, float[][] rotV, float[] posT, float[][] posV) {
        rt[bone] = rotT; rv[bone] = rotV; pt[bone] = posT; pv[bone] = posV;
    }

    /** Interpola linearmente (segura no ultimo frame, como hold_on_last_frame). */
    public static void sample(float[] t, float[][] v, float time, float[] out) {
        int n = t.length;
        if (n == 1 || time <= t[0]) { System.arraycopy(v[0], 0, out, 0, 3); return; }
        if (time >= t[n - 1]) { System.arraycopy(v[n - 1], 0, out, 0, 3); return; }
        int i = 0;
        while (i < n - 2 && time >= t[i + 1]) i++;
        float a = (time - t[i]) / (t[i + 1] - t[i]);
        for (int k = 0; k < 3; k++) out[k] = v[i][k] + (v[i + 1][k] - v[i][k]) * a;
    }
}
