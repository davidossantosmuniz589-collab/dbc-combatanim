#!/usr/bin/env python3
"""Converte animacoes Bedrock (.json 1.8.0) em ComboData.java.
Uso: python3 tools/convert.py  (gera ../src/main/java/dbcanim/anim/ComboData.java)
Molang: q.target_*/q.life_time/q.anim_time viram 0 (sem balanco sutil); math.sin/cos usam graus."""
import json, math, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
BONES = {'waist':0,'root':1,'head':2,'rightArm':3,'leftArm':4,'rightLeg':5,'leftLeg':6,'body':7}

def ev(v):
    if isinstance(v,(int,float)): return float(v)
    s = v
    for k in ('q.target_x_rotation','q.target_y_rotation','q.life_time','q.anim_time'):
        s = s.replace(k,'0')
    s = s.replace('math.sin','msin').replace('math.cos','mcos')
    return float(eval(s,{'__builtins__':{}},{'msin':lambda x:math.sin(math.radians(x)),'mcos':lambda x:math.cos(math.radians(x))}))

def vec(v): return [ev(x) for x in v]

def channel(raw):
    """-> (times, values). Aceita vetor fixo ou dict de keyframes."""
    if isinstance(raw,dict):
        keys = sorted(raw, key=float)
        vals=[]
        for k in keys:
            x = raw[k]
            if isinstance(x,dict): x = x.get('post', x.get('pre'))
            vals.append(vec(x))
        return [float(k) for k in keys], vals
    return [0.0],[vec(raw)]

def fl(x): return ('%.5f'%x).rstrip('0').rstrip('.')+'f' if x!=0 else '0f'
def arr1(a): return 'new float[]{'+','.join(fl(x) for x in a)+'}'
def arr2(a): return 'new float[][]{'+','.join('{'+','.join(fl(x) for x in v)+'}' for v in a)+'}'

def clip_java(var, anim):
    out=[]
    out.append('    Clip %s = new Clip(%s);'%(var, fl(float(anim.get('animation_length') or 1.0))))
    for bone,chs in anim['bones'].items():
        if bone not in BONES: continue
        rt,r = channel(chs['rotation']) if 'rotation' in chs else (None,None)
        pt,p = channel(chs['position']) if 'position' in chs else (None,None)
        out.append('    %s.set(%d, %s, %s, %s, %s);'%(var,BONES[bone],
            arr1(rt) if rt else 'null', arr2(r) if r else 'null',
            arr1(pt) if pt else 'null', arr2(p) if p else 'null'))
    return '\n'.join(out)

def main():
    dbe = json.load(open(os.path.join(HERE,'player_dbe_animation.json')))['animations']
    cmb = json.load(open(os.path.join(HERE,'combat_animation.json')))['animations']
    body=[]
    names=[]
    for i in range(1,7):
        body.append('  static Clip a%d(){\n%s\n    return a%d;\n  }'%(i, clip_java('a%d'%i, dbe['animation.player.melee.attack_%d'%i]).replace('Clip a%d ='%i,'Clip a%d ='%i), i))
    body.append('  static Clip defense(){\n%s\n    return d;\n  }'%clip_java('d', cmb['animation.player.defense']))
    src = ('// GERADO por tools/convert.py - nao edite a mao.\npackage dbcanim.anim;\n\n'
           'public final class ComboData {\n'
           '  public static final Clip[] ATTACKS = { a1(), a2(), a3(), a4(), a5(), a6() };\n'
           '  public static final Clip DEFENSE = defense();\n\n'+'\n\n'.join(body)+'\n}\n')
    dest = os.path.join(HERE,'..','src','main','java','dbcanim','anim','ComboData.java')
    open(dest,'w').write(src)
    print('ok ->',os.path.normpath(dest), len(src),'bytes')
main()
