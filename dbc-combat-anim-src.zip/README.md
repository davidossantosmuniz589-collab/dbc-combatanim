# DBC Combat Anim (Forge 1.7.10)
Socos 1-6 e defesa do addon Bedrock, para o Dragon Block C.

## Compilar
1. Instale JDK 8 e o ForgeGradle 1.2 (projeto Forge 1.7.10-10.13.4.1614). Copie esta pasta para um workspace Forge.
2. `gradlew build` -> jar em build/libs. Coloque em .minecraft/mods junto com DBC/JRMCore/JBRA.

## Regenerar animacoes
`python3 tools/convert.py` (le os dois JSON em tools/ e reescreve ComboData.java).

## Pontos a testar/ajustar
- `DefenseCheck.isDefending`: troque pelo flag de bloqueio do DBC.
- `AnimHook`: constantes SX/SY/SZ e PX/PY/PZ (sinais Bedrock->Java). Se um braco girar para o lado errado, inverta o sinal.
- Se o JBRA Client usar um modelo que nao chama ModelBiped.setRotationAngles, o hook nao age.
